<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Drumblys</title>
    <link rel="stylesheet" href="styles.css">


</head>
<body>
    <header>
        <div class="container">
        <div class="row">
        <div class="drumblys">
         <a href="#home" class="logo"><span>Drum</span>'blys</a>
        </div>
            
        <div class="ham-burger">
            <i class="fa fa-bars"></i>
            </div>
            
         <div class="navbar">
         <ul>
             <li><a href="#apie" class="active">Apie</a></li>
             <li><a href="#services">Grupės</a></li>
             <li><a href="#gallery">Galerija</a></li>
             <li><a href="#blogs">Blogas</a></li>
             <li><a href="#contact">Susisiekite</a></li>
             </ul>
        </div>
        </div>
            </div>
    </header>

<!-- Pagrindinis -->
<section class="home" id="home">
    <div class="container">
        <div class="row full-screen">
            <div class="home-content">
                <div class="block">
            <h6>Sveiki, esame</h6>
            <h1>RITMO MOKYKLA</h1>
            <h3>Vilniuje</h3>
            <div class="register-btn">
                <a href="#contact">Registruotis</a>
                </div>
                </div>
            </div>
        </div>
    </div>
    </section>
    
<!-- Pagrindinis end -->

<!-- Apie -->
<section class="apie" id="apie">
    <div class="container">
    <div class="row">
    <div class="section-title">
        <h1>Apie Drum'blį</h1>
        <p class="small text-uppercase">Plačiau apie ritmo mokyklą</p>
        </div>
    </div>
    <div class="row">
        <div class="apie-content">
            <div class="row">
        <div class="img">
            <img src="images/about.jpg" alt="about-me"/>
            </div>
            <div class="text">
            <h4>Profesionalios būgnų pamokos</h4>
            <h6>Lorem <span>Ipsum & Lorem </span>Ipsum sid amed <span>Vilniuje</span></h6>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            <div class="info">
                <div class="list">
                <label>Kodėl mes?</label>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut enim ad minim veniam, quis nostrud.</p>
                </div>
                <div class="list">
                <label>Instrumentai:</label>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis aute irure dolor in reprehenderit in voluptate velit esse. </p>
                    </div>
                <div class="list">
                <label>Ko aš išmoksiu?</label>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>
                    </div>
                <div class="list">
                <label>Kur mes esam?</label>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                </div>
                
                <div class="social-links">
                <a href="https://www.facebook.com/Drumblys"><i class="fa fa-facebook"></i></a>
                 <a href=""><i class="fa fa-youtube"></i></a>
                     <a href=""><i class="fa fa-instagram"></i></a>
                     <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
    </section>
    
<!--Grupės-->
<section class="services" id="services">
    <div class="container">
    <div class="row">
        <div class="section-title text-center">
         <h1>Grupės</h1>
        </div>
        </div>
        <div class="row">
        <div class="service-content">
                <div class="box">
                    <div class="icon">
                            <i class="fa fa-child"></i>
                        </div>
                       <h5>Vaikams</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                       <span><br>Kaina: 50&euro;/mėn.</span>
                    </div>
                <div class="box">
                    <div class="icon">
                            <i class="fa fa-female"></i>
                        </div>
                       <h5>Paaugliams</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                    <span><br>Kaina: 50&euro;/mėn.</span>
                    </div>
                <div class="box">
                    <div class="icon">
                            <i class="fa fa-male"></i>
                        </div>
                       <h5>Suaugusiems</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                    <span><br>Kaina: 50&euro;/mėn.</span>
                    </div>
                 <div class="box">
                    <div class="icon">
                            <i class="fa fa-battery-quarter"></i>
                        </div>
                       <h5>Pradedantiesiems</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                     <span><br>Kaina: 50&euro;/mėn.</span>
                    </div>
                 <div class="box">
                    <div class="icon">
                            <i class="fa fa-battery-half"></i>
                        </div>
                       <h5>Pažengusiems</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                     <span><br>Kaina: 50&euro;/mėn.</span>
                    </div>
                 <div class="box">
                    <div class="icon">
                            <i class="fa fa-battery-full"></i>
                        </div>
                       <h5>Pro</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                     <span><br>Kaina: 50&euro;/mėn.</span>
                    </div>
            </div>
                </div>
    </div>
    </section>
    
<!--    Galerija-->
<section class="gallery" id="gallery">
    <div class="container">
        <div class="row">
            <div class="section-title text-center">
                <h1>Galerija</h1>
            </div>
        </div>
        <div class="row">
            <div class="filter-buttons">
                <ul id="filter-btns">
                    <li class="active" data-target="all">Visos</li>
                    <li data-target="festival">Festivaliai</li>
                    <li data-target="concert">Koncertai</li>
                    <li data-target="studio">Studija</li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="portfolio-gallery">
                <div class="item" data-id="festival">
                    <div class="inner">
                <img src="images/1.jpg" alt="playing-drums"/>
                <div class="overlay">
                    <span class="fa fa-plus"> </span>
                    <h4>Vasara</h4>
                    </div>
                     </div>
                </div>
                 <div class="item" data-id="concert">
                      <div class="inner">
                <img src="images/2.jpg" alt="concert"/>
                <div class="overlay">
                    <span class="fa fa-plus"> </span>
                    <h4>Koncertas 2018</h4>
                    </div>
                 </div>
                </div>
                 <div class="item" data-id="concert">
                      <div class="inner">
                <img src="images/3.jpg" alt="playing-drums"/>
                <div class="overlay">
                    <span class="fa fa-plus"> </span>
                    <h4>Vasaros terasa</h4>
                    </div>
                     </div>
                </div>
                 <div class="item" data-id="studio">
                      <div class="inner">
                <img src="images/4.jpg" alt="drums"/>
                <div class="overlay">
                    <span class="fa fa-plus"> </span>
                    <h4>Būgnai</h4>
                    </div>
                     </div>
                </div>
                 <div class="item" data-id="festival">
                      <div class="inner">
                <img src="images/5.jpg" alt="playing-drums"/>
                <div class="overlay">
                    <span class="fa fa-plus"> </span>
                    <h4>Pavasaris 2019</h4>
                    </div>
                     </div>
                </div>
                 <div class="item" data-id="studio">
                      <div class="inner">
                <img src="images/6.jpg" alt="playing-drums"/>
                <div class="overlay">
                    <span class="fa fa-plus"> </span>
                    <h4>Studija</h4>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    
<!--Big Photo-->
<div class="lightbox hide">
    <span class="close-lightbox fa fa-close"></span>
      <img src="images/6.jpg" alt="playing-drums"/>
    </div>
    

<!--Testimonials-->
    <section class="testimonials">
        <div class="container">
            <div class="row">
                <div class="section-title text-center">
                    <h1>Atsiliepimai</h1>
                </div>
            </div>
            <div class="row">
            <div class="testimonials-content">
                <div class="testi-slider">
                    <div class="slide">
                        <div class="img">
                         <img src="images/7.png" alt="person"/>
                        </div>
                        <div class="text">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                        <h6>Justinas</h6>
                        <p>Būgnininkas</p>
                        </div>
                    </div>
                            <div class="slide">
                        <div class="img">
                         <img src="images/8.png" alt="person"/>
                        </div>
                        <div class="text">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                        <h6>Greta</h6>
                        <p>Studentė</p>
                        </div>
                    </div>
                            <div class="slide">
                        <div class="img">
                         <img src="images/9.png" alt="person"/>
                        </div>
                        <div class="text">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                        <h6>Vytautas</h6>
                        <p>Alumnas</p>
                        </div>
                    </div>
                            <div class="slide">
                        <div class="img">
                         <img src="images/10.png" alt="person"/>
                        </div>
                        <div class="text">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                        <h6>Agnė</h6>
                        <p>Alumnė</p>
                        </div>
                    </div>
                </div>
                
                <div class="slide-controls">
                
                </div>
                
                </div>
            </div>
        </div>
    </section>
    
<!-- Blogas -->
    
<section class="blogs" id="blogs">
    <div class="container">
        <div class="row">
            <div class="section-title text-center">
                <h1>Blogas</h1>
            </div>
        </div>
        <div class="row">
            <div class="blogs-content">
                <div class="box">
                <div class="img">
                    <img src="images/11.jpg" alt="drums" />
                    </div>
                    <div class="info">
                    <span>2019 m. balandžio 5 d.</span> <span>Koncertai</span>
                    </div>
                    <h3>Lorem ipsum lorem</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <a href="">Plačiau</a>
                </div>
                <div class="box">
                <div class="img">
                    <img src="images/12.jpg" alt="drums" />
                    </div>
                    <div class="info">
                    <span>2020 m. sausio 18 d.</span> <span>Muzika</span>
                    </div>
                    <h3>Lorem ipsum lorem</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <a href="">Plačiau</a>
                </div>
                <div class="box">
                <div class="img">
                    <img src="images/13.jpg" alt="drums" />
                    </div>
                    <div class="info">
                    <span>2020 m. vasario 19 d.</span> <span>Pamokos</span>
                    </div>
                    <h3>Lorem ipsum lorem</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <a href="">Plačiau</a>
                </div>
            </div>
        </div>
    </div>
</section>
    
<!--- Kontaktine forma --->

  <?php
require __DIR__ . '/../drumblys/contact/app.php';
?> 
    
<?php
        include ('../drumblys/contact.php');
        ?>
    
    
    
<!--- Footer --->
    <footer>
        <section class="copyright">
            <div class="container">
                <p>&copy; <?php echo date("Y"); ?> all rights reserved</p>
            </div>
        </section>
    </footer>
    
<script src="scripts.js"></script> 
    
    
    
</body>
</html>
