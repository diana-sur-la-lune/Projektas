
<section class="contact-us" id="contact">
    <div class="container">
        <div class="row">
            <div class="section-title text-center">
            <h1>Užsiregistruokite</h1>
            </div>
        </div>
        <div class="row">
            <div class="contact-form" method="post" action="app.php">
                <div class="row">
                    <div class="text">
                        <h2>Norite prisijungti ar turite klausimų?</h2>
                        <p>Užpildykite formą ir mes susisieksime su Jumis.</p>
                    </div>
                </div>
                <div class="forma">
                <form id="contact" action="index.php" method="post">
                    <div class="col-6">
                     <input type="text" class="form-control" name="name" placeholder="Vardas" required autofocus>
                    </div>
                    <div class="col-6">
                     <input type="text" class="form-control" name="mail" placeholder="El. paštas" required>
                    </div>
                <div class="row">
                    <div class="col-12">
                    <textarea class="form-control" name="message" placeholder="Jūsų žinutė" required></textarea>
                    </div>
                </div>
                    <button name="submit" type="submit" id="contact-submit">Siųsti</button>
                    </form>
                </div>
                </div>
            </div>
         </div>
    </section>
    