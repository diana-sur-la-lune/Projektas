<?php
if(isset($_POST['submit'])) {
$name = trim($_POST['name']);
//$mail = trim($_POST['mail']);
$message = trim($_POST['message']);

if(!empty($name) && !empty($mail) && !empty($message)) {
if(filter_var($mail, FILTER_VALIDATE_EMAIL)) {
$from = "$mail";
$to = "dia.voinova@gmail.com";
$subject = "Nauja žinutė";
$autorius = 'Nuo: ' . $name . ', ' . $mail;
$zinute = htmlspecialchars($message);
mail($to, $subject, $autorius, $zinute, $from);
echo "<script>alert('Dekojame. Jusu zinute gauta. Netrukus susisieksime.');</script>";
}
}
include ('db.php');
}
?>